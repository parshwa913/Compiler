#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef enum { TOKEN_BLOCK, TOKEN_CONNECT, TOKEN_ID, TOKEN_COMMA, TOKEN_END, TOKEN_ERROR } TokenType;

typedef struct {
    TokenType type;
    char value[32];
} Token;

const char *input;
int position = 0;

Token get_next_token() {
    while (isspace(input[position])) position++;
    
    Token token;
    if (position >= strlen(input)) {
        token.type = TOKEN_END; 
        return token;
    }
    
    if (strncmp(&input[position], "BLOCK", 5) == 0) {
        token.type = TOKEN_BLOCK;
        strcpy(token.value, "BLOCK");
        position += 5;
    } else if (strncmp(&input[position], "CONNECT", 7) == 0) {
        token.type = TOKEN_CONNECT;
        strcpy(token.value, "CONNECT");
        position += 7;
    } else if (isalnum(input[position])) {
        int start = position;
        while (isalnum(input[position]) || input[position] == '_') position++;
        strncpy(token.value, &input[start], position - start);
        token.value[position - start] = '\0';
        token.type = TOKEN_ID;
    } else if (input[position] == ',') {
        token.type = TOKEN_COMMA;
        token.value[0] = ',';
        token.value[1] = '\0';
        position++;
    } else {
        token.type = TOKEN_ERROR; 
    }
    
    printf("Generated token: Type=%d, Value='%s'\n", token.type, token.value);  
    return token;
}

typedef struct Block {
    char id[32];
    char inputs[2][32];  
    struct Block *next;
} Block;

typedef struct Connection {
    char from[32];
    char to[32];
    struct Connection *next;
} Connection;

Block *blocks = NULL;
Connection *connections = NULL;

void add_block(char *id, char *input1, char *input2) {
    Block *new_block = (Block *)malloc(sizeof(Block));
    strcpy(new_block->id, id);
    strcpy(new_block->inputs[0], input1);
    strcpy(new_block->inputs[1], input2);
    new_block->next = blocks;
    blocks = new_block;
}

void add_connection(char *from, char *to) {
    Connection *new_connection = (Connection *)malloc(sizeof(Connection));
    strcpy(new_connection->from, from);
    strcpy(new_connection->to, to);
    new_connection->next = connections;
    connections = new_connection;
}

void parse() {
    Token token = get_next_token();
    while (token.type != TOKEN_END) {
        if (token.type == TOKEN_BLOCK) {
            token = get_next_token(); 
            if (token.type != TOKEN_ID) {
                printf("Error: Expected block ID after BLOCK keyword.\n");
                return;
            }
            char block_id[32];
            strcpy(block_id, token.value);

            char input1[32] = "", input2[32] = "";
            token = get_next_token(); 
            if (token.type == TOKEN_COMMA) {
                token = get_next_token();
                if (token.type != TOKEN_ID) {
                    printf("Error: Expected input ID after comma.\n");
                    return;
                }
                strcpy(input1, token.value);

                token = get_next_token();
                if (token.type == TOKEN_COMMA) {
                    token = get_next_token();
                    if (token.type != TOKEN_ID) {
                        printf("Error: Expected second input ID after comma.\n");
                        return;
                    }
                    strcpy(input2, token.value);
                    token = get_next_token();  
                }
            }

            add_block(block_id, input1, input2);
        } else if (token.type == TOKEN_CONNECT) {
            token = get_next_token(); 
            if (token.type != TOKEN_ID) {
                printf("Error: Expected from block ID.\n");
                return;
            }
            char from_id[32];
            strcpy(from_id, token.value);

            token = get_next_token(); 
            if (token.type != TOKEN_ID) {
                printf("Error: Expected to block ID.\n");
                return;
            }
            char to_id[32];
            strcpy(to_id, token.value);
            add_connection(from_id, to_id);
            
            token = get_next_token();
        } else {
            printf("Error: Unexpected token.\n");
            return;
        }
    }
}

void print_blocks_and_connections() {
    printf("Blocks:\n");
    Block *b = blocks;
    while (b) {
        printf("  %s (inputs: %s, %s)\n", b->id, b->inputs[0], b->inputs[1]);
        b = b->next;
    }

    printf("Connections:\n");
    Connection *c = connections;
    while (c) {
        printf("  %s -> %s\n", c->from, c->to);
        c = c->next;
    }
}

void print_parse_tree(Block *blocks) {
    printf("Parse Tree:\n");
    for (Block *b = blocks; b != NULL; b = b->next) {
        printf("  Block: %s\n", b->id);
        for (int i = 0; i < 2; i++) {
            if (b->inputs[i][0] != '\0') {
                printf("    Input: %s\n", b->inputs[i]);
            }
        }
    }
    
    Connection *c = connections;
    while (c) {
        printf("  Connection: %s -> %s\n", c->from, c->to);
        c = c->next;
    }
}

void generate_three_address_code(Block *blocks) {
    printf("\nThree-Address Code:\n");
    Block *b = blocks;
    int temp_count = 1;

    while (b) {
        char temp1[10], temp2[10];

        if (b->inputs[0][0] != '\0') {
            sprintf(temp1, "t%d", temp_count++);
            printf("%s = %s\n", temp1, b->inputs[0]); 
        }
        if (b->inputs[1][0] != '\0') {
            sprintf(temp2, "t%d", temp_count++);
            printf("%s = %s\n", temp2, b->inputs[1]); 
        }
        
        printf("CALL %s, %s, %s\n", b->id, (b->inputs[0][0] != '\0') ? temp1 : "NULL", (b->inputs[1][0] != '\0') ? temp2 : "NULL");
        b = b->next;
    }
}

void generate_assembly_code(Block *blocks) {
    printf("\nAssembly Code:\n");
    Block *b = blocks;
    while (b) {
        if (b->inputs[0][0] != '\0') {
            printf("LOAD R0, %s\n", b->inputs[0]); 
        }
        if (b->inputs[1][0] != '\0') {
            printf("LOAD R1, %s\n", b->inputs[1]); 
        }
        printf("CALL %s\n", b->id); 
        b = b->next;
    }

    Connection *c = connections;
    while (c) {
        printf("CONNECT %s, %s\n", c->from, c->to);
        c = c->next;
    }
}

void semantic_analysis(Block *blocks, Connection *connections) {
    for (Block *b = blocks; b != NULL; b = b->next) {
        for (Block *other_b = blocks; other_b != NULL; other_b = other_b->next) {
            if (b != other_b && strcmp(b->id, other_b->id) == 0) {
                printf("Error: Duplicate block ID '%s'\n", b->id);
                return;
            }
        }
    }

    for (Connection *c = connections; c != NULL; c = c->next) {
        Block *from_block = NULL;
        Block *to_block = NULL;
        for (Block *b = blocks; b != NULL; b = b->next) {
            if (strcmp(b->id, c->from) == 0) {
                from_block = b;
            }
            if (strcmp(b->id, c->to) == 0) {
                to_block = b;
            }
        }
        if (from_block == NULL || to_block == NULL) {
            printf("Error: Invalid connection '%s' -> '%s'\n", c->from, c->to);
            return;
        }
    }

    for (Block *b = blocks; b != NULL; b = b->next) {
        for (int i = 0; i < 2; i++) {
            if (b->inputs[i][0] != '\0') {
                Block *input_block = NULL;
                for (Block *other_b = blocks; other_b != NULL; other_b = other_b->next) {
                    if (strcmp(other_b->id, b->inputs[i]) == 0) {
                        input_block = other_b;
                    }
                }
                if (input_block == NULL) {
                    printf("Error: Invalid input '%s' for block '%s'\n", b->inputs[i], b->id);
                    return;
                }
            }
        }
    }
}

int main() {
    char input_buffer[256];
    printf("Enter your visual programming language input with ('END'):\n");
    
    input_buffer[0] = '\0';
    while (1) {
        fgets(input_buffer + strlen(input_buffer), sizeof(input_buffer) - strlen(input_buffer), stdin);
        if (strncmp(input_buffer + strlen(input_buffer) - 4, "END", 3) == 0) {
            input_buffer[strlen(input_buffer) - 4] = '\0'; 
            break;
        }
    }

    input = input_buffer; 
    position = 0;

    parse();
    print_blocks_and_connections(); 
    print_parse_tree(blocks); 
    generate_three_address_code(blocks);
    generate_assembly_code(blocks); 
    
    return 0;
}
