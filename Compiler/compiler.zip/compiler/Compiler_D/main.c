#include <stdio.h>
#include <string.h>
#include "token.h"
#include "parser.h"
#include "structures.h"

// Global variables for input handling
const char *input;
int position = 0;

int main() {
    // Allocate buffer for input
    char input_buffer[256];
    printf("Enter your visual programming language input (end with 'END'):\n");
    
    // Read user input until "END"
    input_buffer[0] = '\0'; // Initialize buffer
    while (1) {
        fgets(input_buffer + strlen(input_buffer), sizeof(input_buffer) - strlen(input_buffer), stdin);
        if (strncmp(input_buffer + strlen(input_buffer) - 4, "END", 3) == 0) {
            input_buffer[strlen(input_buffer) - 4] = '\0'; // Remove "END"
            break;
        }
    }

    input = input_buffer; // Assign to input for parsing
    position = 0;

    parse(); // Lexical and Syntax Analysis
    print_blocks_and_connections(); // Print blocks and connections

    return 0;
}