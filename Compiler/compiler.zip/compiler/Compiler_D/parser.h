#ifndef PARSER_H
#define PARSER_H

void parse();

#endif // PARSER_H