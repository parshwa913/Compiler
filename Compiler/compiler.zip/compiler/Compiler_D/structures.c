#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structures.h"

Block *blocks = NULL;
Connection *connections = NULL;

void add_block(char *id, char *input1, char *input2) {
    Block *new_block = (Block *)malloc(sizeof(Block));
    strcpy(new_block->id, id);
    strcpy(new_block->inputs[0], input1);
    strcpy(new_block->inputs[1], input2);
    new_block->next = blocks;
    blocks = new_block;
}

void add_connection(char *from, char *to) {
    Connection *new_connection = (Connection *)malloc(sizeof(Connection));
    strcpy(new_connection->from, from);
    strcpy(new_connection->to, to);
    new_connection->next = connections;
    connections = new_connection;
}

void print_blocks_and_connections() {
    printf("Blocks:\n");
    Block *b = blocks;
    while (b) {
        printf("  %s (inputs: %s, %s)\n", b->id, b->inputs[0], b->inputs[1]);
        b = b->next;
    }

    printf("Connections:\n");
    Connection *c = connections;
    while (c) {
        printf("  %s -> %s\n", c->from, c->to);
        c = c->next;
    }
}