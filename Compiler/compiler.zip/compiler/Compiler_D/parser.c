#include <stdio.h>
#include <string.h>
#include "token.h"
#include "structures.h"

// External variables
extern const char *input;
extern int position;

void parse() {
    Token token = get_next_token();
    while (token.type != TOKEN_END) {
        if (token.type == TOKEN_BLOCK) {
            token = get_next_token(); // Get ID
            if (token.type != TOKEN_ID) {
                printf("Error: Expected block ID after BLOCK keyword.\n");
                return;
            }
            char block_id[32];
            strcpy(block_id, token.value);

            // Expecting inputs or no inputs
            char input1[32] = "", input2[32] = "";
            token = get_next_token(); // Get either comma or next keyword
            if (token.type == TOKEN_COMMA) {
                // Parse first input
                token = get_next_token();
                if (token.type != TOKEN_ID) {
                    printf("Error: Expected input ID after comma.\n");
                    return;
                }
                strcpy(input1, token.value);

                // Try to get second input
                token = get_next_token();
                if (token.type == TOKEN_COMMA) {
                    token = get_next_token();
                    if (token.type != TOKEN_ID) {
                        printf("Error: Expected second input ID after comma.\n");
                        return;
                    }
                    strcpy(input2, token.value);
                    token = get_next_token();  // Prepare for next statement
                }
            }

            // Add block to the list
            add_block(block_id, input1, input2);

        } else if (token.type == TOKEN_CONNECT) {
            token = get_next_token(); // Get from ID
            if (token.type != TOKEN_ID) {
                printf("Error: Expected from block ID.\n");
                return;
            }
            char from_id[32];
            strcpy(from_id, token.value);

            token = get_next_token(); // Get to ID (without requiring comma)
            if (token.type != TOKEN_ID) {
                printf("Error: Expected to block ID.\n");
                return;
            }
            char to_id[32];
            strcpy(to_id, token.value);
            add_connection(from_id, to_id);
            
            // Move on to the next token
            token = get_next_token();
        } else {
            printf("Error: Unexpected token.\n");
            return;
        }
    }
}