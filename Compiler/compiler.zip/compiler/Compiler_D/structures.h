#ifndef STRUCTURES_H
#define STRUCTURES_H

typedef struct Block {
    char id[32];
    char inputs[2][32];
    struct Block *next;
} Block;

typedef struct Connection {
    char from[32];
    char to[32];
    struct Connection *next;
} Connection;

void add_block(char *id, char *input1, char *input2);
void add_connection(char *from, char *to);
void print_blocks_and_connections();

#endif // STRUCTURES_H