#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "token.h"

// External variables
extern const char *input;
extern int position;

Token get_next_token() {
    while (isspace(input[position])) position++;

    Token token;
     if (position >= strlen(input)) {
        token.type = TOKEN_END;
        return token;
    }
    if (strncmp(&input[position], "BLOCK", 5) == 0) {
        token.type = TOKEN_BLOCK;
        strcpy(token.value, "BLOCK");
        position += 5;
    } else if (strncmp(&input[position], "CONNECT", 7) == 0) {
        token.type = TOKEN_CONNECT;
        strcpy(token.value, "CONNECT");
        position += 7;
    } else if (isalnum(input[position])) {
        int start = position;
        while (isalnum(input[position]) || input[position] == '_') position++;
        strncpy(token.value, &input[start], position - start);
        token.value[position - start] = '\0';
        token.type = TOKEN_ID;
    } else if (input[position] == ',') {
        token.type = TOKEN_COMMA;
        token.value[0] = ',';
        token.value[1] = '\0';
        position++;
    }
    //  else if (input[position] == '\0') {
    //     token.type = TOKEN_END;
    // } 
    else {
        token.type = TOKEN_ERROR;
    }
    printf("Generated token: Type=%d, Value='%s'\n", token.type, token.value);
    return token;
}