#ifndef TOKEN_H
#define TOKEN_H

typedef enum { TOKEN_BLOCK, TOKEN_CONNECT, TOKEN_ID, TOKEN_COMMA, TOKEN_END, TOKEN_ERROR } TokenType;

typedef struct {
    TokenType type;
    char value[32];
} Token;

Token get_next_token();

#endif // TOKEN_H