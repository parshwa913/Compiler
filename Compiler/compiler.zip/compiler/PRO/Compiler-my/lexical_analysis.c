#include "compiler.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>

void add_token(const char* type, const char* value) {
    strcpy(tokens[token_count].type, type);
    strcpy(tokens[token_count].value, value);
    token_count++;
}

void lexical_analysis(const char* code) {
    int i = 0;
    char ch;
    while ((ch = code[i]) != '\0') {
        if (isalpha(ch)) {
            char buffer[TOKEN_LEN] = {0};
            int k = 0;
            while (isalnum(code[i])) {
                buffer[k++] = code[i++];
            }
            add_token("IDENTIFIER", buffer);
        } else if (isdigit(ch)) {
            char buffer[TOKEN_LEN] = {0};
            int k = 0;
            while (isdigit(code[i])) {
                buffer[k++] = code[i++];
            }
            add_token("NUMBER", buffer);
        } else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
            char buffer[2] = {ch, '\0'};
            add_token("OPERATOR", buffer);
            i++;
        } else {
            i++;
        }
    }
}

void display_tokens() {
    for (int i = 0; i < token_count; i++) {
        printf("Token: Type = %s, Value = %s\n", tokens[i].type, tokens[i].value);
    }
}
