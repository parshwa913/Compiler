// compiler.h
#ifndef COMPILER_H
#define COMPILER_H

#define MAX_TOKENS 100
#define TOKEN_LEN 64

typedef struct {
    char type[TOKEN_LEN];
    char value[TOKEN_LEN];
} Token;

extern Token tokens[MAX_TOKENS];
extern int token_count;

// Function declarations
void add_token(const char* type, const char* value);
void lexical_analysis(const char* code);
void display_tokens();
void syntax_analysis();
int semantic_analysis();

#endif
