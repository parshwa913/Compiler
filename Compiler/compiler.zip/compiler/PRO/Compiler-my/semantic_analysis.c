#include "compiler.h"
#include <stdio.h>
#include <string.h>

int semantic_analysis() {
    for (int i = 0; i < token_count; i++) {
        if (strcmp(tokens[i].type, "IDENTIFIER") == 0) {
            if (strcmp(tokens[i + 1].value, "=") == 0) {
                if (strcmp(tokens[i + 2].type, "NUMBER") != 0) {
                    printf("Semantic error: Variable should be assigned a number.\n");
                    return 0;
                }
            }
        }
    }
    return 1;
}
