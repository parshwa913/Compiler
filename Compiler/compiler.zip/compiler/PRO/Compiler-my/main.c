#include "compiler.h"
#include <stdio.h>

int main() {
    const char* code = "x = 10 + 20";
    
    // Perform lexical analysis
    lexical_analysis(code);
    display_tokens();

    // Perform syntax analysis
    syntax_analysis();

    // Perform semantic analysis
    if (semantic_analysis()) {
        printf("Semantic analysis passed.\n");
    } else {
        printf("Semantic error.\n");
    }

    return 0;
}
