#include "compiler.h"
#include <stdio.h>
#include <string.h>

int current_token = 0;

int expression() {
    if (strcmp(tokens[current_token].type, "IDENTIFIER") == 0) {
        current_token++;
        if (strcmp(tokens[current_token].value, "=") == 0) {
            current_token++;
            if (strcmp(tokens[current_token].type, "NUMBER") == 0) {
                current_token++;
                if (strcmp(tokens[current_token].type, "OPERATOR") == 0) {
                    current_token++;
                    if (strcmp(tokens[current_token].type, "NUMBER") == 0) {
                        return 1; // Valid expression
                    }
                }
            }
        }
    }
    return 0; // Invalid expression
}

void syntax_analysis() {
    if (expression()) {
        printf("Syntax is correct.\n");
    } else {
        printf("Syntax error detected.\n");
    }
}
