#include<stdio.h>
#include<conio.h>

int main() {
    int x;
    int y;
    int z;
    float f;
    x=3;
    y=10;
    z=5;
    for(i=0; i<10; i++) {
        printf("Hello World");
        for(j=0; j<z; j++) {
            printf("Bye World");
        }
    }
    if(y>z) {
        char c;
        c='A';
    }
    else {
        f=3.14;
    }
    return 0;
}