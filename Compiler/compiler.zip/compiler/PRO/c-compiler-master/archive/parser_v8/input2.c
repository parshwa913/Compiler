#include<stdio.h>
#include<string.h>

int main() {
    int x=1;
    float f;
    int a=3;
    a = x + 5;
}