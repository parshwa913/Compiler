#include<stdio.h>
#include<string.h>

int main() {
    int a;
    int x=1;
    int y=2;
    int z=3;
    char f=97;
    x=3;
    y=10;
    z=5;
    for(int i=0; i<10; i++) {
        printf("Hello World");
        scanf("%d", &x);
        for(int j=0; j<z; j++) {
            f=1;
        }
    }
    return 0;
}