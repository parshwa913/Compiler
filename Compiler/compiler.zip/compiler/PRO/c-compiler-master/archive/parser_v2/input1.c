#include<iostream.h>
#include<conio.h>

int main(){
    int x;
    x = y+3;
    if(x>y){
        i=j;
    }
    else{
        int i;
        i=m;
    }
    int y;
    y= m*4;
    printf("hey");
    for(i=0;i<5;i++){
        int a;
        a = b+c;
        for(j=0; j<10; j++){
            x = y;
        }
        l = m/n;

        if(true){
            i=j;
        }
        else{
            i=m;
        }
    }
    int q;
    q = r*s;
    return 0;
}