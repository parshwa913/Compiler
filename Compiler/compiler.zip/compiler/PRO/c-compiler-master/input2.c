#include<stdio.h>
#include<string.h>

int main() {
    int i=1;
    float f = 2.5;
    char c = 'A';
    int x = 3.5;
    i = x + f * c;
    return 3;
}